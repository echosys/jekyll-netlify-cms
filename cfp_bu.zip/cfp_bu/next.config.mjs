/** @type {import('next').NextConfig} */
const nextConfig = {
    webpack: (config) => {
        config.resolve.fallback = {
            ...config.resolve.fallback,
            fs: false,
            path: false,
            net: false,
            tls: false,
            dns: false,
            os: false,
            stream: false,
            crypto: false,
            string_decoder: false,
            events: false,
            process: false,
            'pg-native': false,
        };
        return config;
    },
};

export default nextConfig;
