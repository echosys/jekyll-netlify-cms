"use server";

import { db } from "@/lib/db";
import { processAttachment } from "@/lib/storage";
import { revalidatePath } from "next/cache";

export interface Post {
    id: number;
    title: string;
    content: string;
    attachment_name: string | null;
    attachment_data: string | null;
    created_at: Date;
}

export async function createPost(formData: FormData) {
    const title = formData.get("title") as string;
    const content = formData.get("content") as string;
    const file = formData.get("attachment") as File | null;

    let attachmentName = null;
    let attachmentBase64 = null;

    if (file && file.size > 0) {
        const result = await processAttachment(file);
        attachmentName = result.name;
        attachmentBase64 = result.base64;
    }

    await db.query(
        "INSERT INTO posts (title, content, attachment_name, attachment_data) VALUES ($1, $2, $3, $4)",
        [title, content, attachmentName, attachmentBase64]
    );

    revalidatePath("/");
}

export async function getPosts(): Promise<Post[]> {
    const { rows } = await db.query(
        "SELECT id, title, content, attachment_name, created_at FROM posts ORDER BY created_at DESC"
    );
    return rows;
}

export async function getAttachment(id: number) {
    const { rows } = await db.query(
        "SELECT attachment_name, attachment_data FROM posts WHERE id = $1",
        [id]
    );

    const post = rows[0];
    if (!post || !post.attachment_name || !post.attachment_data) return null;

    // Convert base64 back to ArrayBuffer for the response
    const data = Buffer.from(post.attachment_data, 'base64');

    return {
        name: post.attachment_name,
        data: data.buffer
    };
}
