import { createPost } from "../actions";
import Link from "next/link";
import { ArrowLeft, Save, Upload } from "lucide-react";
import { blogConfig } from "@/blog.config";

export const runtime = 'edge';

export default function NewPost() {
    return (
        <div className="max-w-2xl mx-auto">
            <div className="mb-8">
                <Link href="/" className="text-slate-500 hover:text-slate-300 flex items-center gap-2 transition-colors">
                    <ArrowLeft size={18} /> Back to Blog
                </Link>
            </div>

            <h2 className="text-3xl font-bold mb-8">Create New Post</h2>

            <form action={createPost} className="space-y-6 bg-slate-900/50 p-8 rounded-2xl border border-slate-800">
                <div className="space-y-2">
                    <label htmlFor="title" className="text-sm font-medium text-slate-400">Title</label>
                    <input
                        id="title"
                        name="title"
                        type="text"
                        required
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:ring-2 focus:ring-orange-500 outline-none transition-all placeholder:text-slate-700"
                        placeholder="Enter post title..."
                    />
                </div>

                <div className="space-y-2">
                    <label htmlFor="content" className="text-sm font-medium text-slate-400">Content</label>
                    <textarea
                        id="content"
                        name="content"
                        required
                        rows={8}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:ring-2 focus:ring-orange-500 outline-none transition-all placeholder:text-slate-700 resize-none"
                        placeholder="Write your blog content here..."
                    />
                </div>

                <div className="space-y-2">
                    <label htmlFor="attachment" className="text-sm font-medium text-slate-400">Attachment (Max 200MB)</label>
                    <div className="relative group">
                        <input
                            id="attachment"
                            name="attachment"
                            type="file"
                            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                        />
                        <div className="w-full bg-slate-950 border border-slate-800 border-dashed rounded-xl px-4 py-6 flex flex-col items-center gap-3 group-hover:border-slate-600 transition-all pointer-events-none">
                            <Upload className="text-slate-600 group-hover:text-orange-400 transition-colors" size={32} />
                            <div className="text-center">
                                <p className="text-slate-400 text-sm font-medium">Click or drag and drop</p>
                                <p className="text-slate-600 text-xs mt-1">ZIP, PDF, images up to 200MB</p>
                            </div>
                        </div>
                    </div>
                    <p className="text-[10px] text-slate-600 italic">
                        All attachments are stored directly in the Postgres database as base64.
                    </p>
                </div>

                <button
                    type="submit"
                    className="w-full bg-gradient-to-r from-orange-500 to-rose-500 hover:from-orange-600 hover:to-rose-600 text-white font-bold py-4 rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-orange-500/20"
                >
                    <Save size={20} /> Publish Post
                </button>
            </form>
        </div>
    );
}
