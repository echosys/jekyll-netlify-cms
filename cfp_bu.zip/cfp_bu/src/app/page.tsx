import { getPosts } from "./actions";
import Link from "next/link";
import { Paperclip, Plus, Download } from "lucide-react";
export const runtime = 'edge';
export const dynamic = 'force-dynamic';

export default async function Home() {
    const posts = await getPosts();

    return (
        <div className="space-y-8">
            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-semibold">Latest Posts</h2>
                <Link
                    href="/new"
                    className="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-all"
                >
                    <Plus size={18} /> New Post
                </Link>
            </div>

            <div className="grid gap-6">
                {posts.length === 0 ? (
                    <div className="text-center py-20 border-2 border-dashed border-slate-800 rounded-xl text-slate-500">
                        No posts yet. Create your first one!
                    </div>
                ) : (
                    posts.map((post) => (
                        <article
                            key={post.id}
                            className="bg-slate-900 border border-slate-800 p-6 rounded-xl hover:border-slate-700 transition-colors"
                        >
                            <h3 className="text-xl font-bold text-white mb-2">{post.title}</h3>
                            <p className="text-slate-400 line-clamp-3 mb-4">{post.content}</p>

                            <div className="flex justify-between items-center text-sm">
                                <span className="text-slate-500">
                                    {new Date(post.created_at).toLocaleDateString()}
                                </span>

                                {post.attachment_name && (
                                    <div className="flex items-center gap-2 text-orange-400 bg-orange-400/10 px-3 py-1 rounded-full">
                                        <Paperclip size={14} />
                                        <span>{post.attachment_name}</span>
                                    </div>
                                )}
                            </div>
                        </article>
                    ))
                )}
            </div>
        </div>
    );
}
