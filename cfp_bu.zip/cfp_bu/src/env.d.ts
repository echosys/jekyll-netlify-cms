interface CloudflareEnv {
    DB: D1Database;
    BUCKET: R2Bucket;
}
